$(function(){
    $(".prd").mouseover(function(){
        $(this).find(".wname").stop().animate({opacity:"1"},500);
        $(this).find(".desc").stop().animate({opacity:"1"},500);

        $(this).find("img").css({top:"-195px"});
        $(this).find(".divopa").stop().animate({height:"195px"},500,'easeOutBounce');
    })
    $(".prd").mouseout(function(){
        $(this).find(".wname").stop().animate({opacity:"0"},200);
        $(this).find(".desc").stop().animate({opacity:"0"},200);
        $(this).find("img").stop().css({top:"0px"});
        $(this).find(".divopa").stop().animate({height:"0px"},200);
       
    })
    
})
// end JQuery.
